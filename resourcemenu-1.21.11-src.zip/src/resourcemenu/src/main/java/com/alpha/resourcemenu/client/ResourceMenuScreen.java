package com.alpha.resourcemenu.client;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;

import java.util.ArrayList;
import java.util.List;

public class ResourceMenuScreen extends Screen {

    // Layout constants
    private static final int BG_COLOR       = 0xCC0A0A0A;
    private static final int BORDER_COLOR   = 0xFF00FF88;
    private static final int HOVER_COLOR    = 0x8800FF88;
    private static final int HEADER_COLOR   = 0xFF00FF88;
    private static final int SLOT_SIZE      = 20;
    private static final int COLS           = 10;
    private static final int VISIBLE_ROWS   = 7;
    private static final int PANEL_W        = 220;
    private static final int PANEL_H        = 220;

    private TextFieldWidget searchField;
    private List<Item> allItems;
    private List<Item> filteredItems;

    private int scrollOffset = 0;
    private int hoveredIndex = -1;

    private Item selectedItem = null;
    private int giveAmount = 1;

    public ResourceMenuScreen() {
        super(Text.literal("Resource Menu"));
    }

    @Override
    protected void init() {
        allItems = new ArrayList<>();
        Registries.ITEM.forEach(allItems::add);
        filteredItems = new ArrayList<>(allItems);

        int panelX = (this.width  - PANEL_W) / 2;
        int panelY = (this.height - PANEL_H) / 2;

        searchField = new TextFieldWidget(
            this.textRenderer,
            panelX + 5, panelY + 18,
            PANEL_W - 10, 14,
            Text.literal("Search")
        );
        searchField.setMaxLength(50);
        searchField.setPlaceholder(Text.literal("Search items..."));
        searchField.setChangedListener(this::onSearch);
        this.addDrawableChild(searchField);
        this.setInitialFocus(searchField);
    }

    private void onSearch(String query) {
        scrollOffset = 0;
        selectedItem = null;
        if (query == null || query.isEmpty()) {
            filteredItems = new ArrayList<>(allItems);
        } else {
            String low = query.toLowerCase();
            filteredItems = new ArrayList<>();
            for (Item item : allItems) {
                String id   = Registries.ITEM.getId(item).toString().toLowerCase();
                String name = item.getName().getString().toLowerCase();
                if (id.contains(low) || name.contains(low)) {
                    filteredItems.add(item);
                }
            }
        }
    }

    @Override
    public void render(DrawContext ctx, int mouseX, int mouseY, float delta) {
        int panelX = (this.width  - PANEL_W) / 2;
        int panelY = (this.height - PANEL_H) / 2;

        ctx.fill(panelX, panelY, panelX + PANEL_W, panelY + PANEL_H, BG_COLOR);
        drawBorder(ctx, panelX, panelY, PANEL_W, PANEL_H, BORDER_COLOR);

        ctx.drawText(textRenderer,
            Text.literal("⚡ RESOURCE MENU"),
            panelX + 5, panelY + 5,
            HEADER_COLOR, false
        );

        ctx.drawText(textRenderer,
            Text.literal(filteredItems.size() + " items"),
            panelX + PANEL_W - 50, panelY + 5,
            0xFFAAAAAA, false
        );

        super.render(ctx, mouseX, mouseY, delta);

        int gridX = panelX + 5;
        int gridY = panelY + 36;

        hoveredIndex = -1;

        int startIdx = scrollOffset * COLS;
        int endIdx   = Math.min(startIdx + COLS * VISIBLE_ROWS, filteredItems.size());

        for (int i = startIdx; i < endIdx; i++) {
            int col = (i - startIdx) % COLS;
            int row = (i - startIdx) / COLS;
            int sx  = gridX + col * SLOT_SIZE;
            int sy  = gridY + row * SLOT_SIZE;

            Item item = filteredItems.get(i);

            boolean hovered = mouseX >= sx && mouseX < sx + SLOT_SIZE
                           && mouseY >= sy && mouseY < sy + SLOT_SIZE;
            if (hovered) {
                hoveredIndex = i;
                ctx.fill(sx, sy, sx + SLOT_SIZE, sy + SLOT_SIZE, HOVER_COLOR);
            }

            if (item == selectedItem) {
                ctx.fill(sx, sy, sx + SLOT_SIZE, sy + SLOT_SIZE, 0x88FFFF00);
            }

            ctx.drawItem(new ItemStack(item), sx + 2, sy + 2);
        }

        int totalRows = (int) Math.ceil((double) filteredItems.size() / COLS);
        if (totalRows > VISIBLE_ROWS) {
            int scrollBarH  = PANEL_H - 44;
            int barH        = Math.max(10, scrollBarH * VISIBLE_ROWS / totalRows);
            int barY        = panelY + 36 + (scrollBarH - barH) * scrollOffset / Math.max(1, totalRows - VISIBLE_ROWS);
            ctx.fill(panelX + PANEL_W - 4, panelY + 36, panelX + PANEL_W - 2, panelY + 36 + scrollBarH, 0xFF333333);
            ctx.fill(panelX + PANEL_W - 4, barY, panelX + PANEL_W - 2, barY + barH, BORDER_COLOR);
        }

        int bottomY = panelY + PANEL_H - 20;
        ctx.fill(panelX, bottomY - 2, panelX + PANEL_W, panelY + PANEL_H, 0xCC111111);

        if (selectedItem != null) {
            String selName = selectedItem.getName().getString();
            if (selName.length() > 18) selName = selName.substring(0, 16) + "..";

            ctx.drawText(textRenderer,
                Text.literal("▶ " + selName),
                panelX + 5, bottomY,
                0xFFFFFF00, false
            );

            drawButton(ctx, panelX + PANEL_W - 70, bottomY - 1, 12, 12, "-", mouseX, mouseY);
            ctx.drawText(textRenderer,
                Text.literal(String.valueOf(giveAmount)),
                panelX + PANEL_W - 55, bottomY,
                0xFFFFFFFF, false
            );
            drawButton(ctx, panelX + PANEL_W - 42, bottomY - 1, 12, 12, "+", mouseX, mouseY);
            drawButton(ctx, panelX + PANEL_W - 28, bottomY - 1, 25, 12, "GIVE", mouseX, mouseY);
        } else {
            ctx.drawText(textRenderer,
                Text.literal("Click item to select"),
                panelX + 5, bottomY,
                0xFF555555, false
            );
        }

        if (hoveredIndex >= 0 && hoveredIndex < filteredItems.size()) {
            Item hItem = filteredItems.get(hoveredIndex);
            Identifier id = Registries.ITEM.getId(hItem);
            ctx.drawTooltip(textRenderer,
                List.of(
                    hItem.getName(),
                    Text.literal(id.toString()).styled(s -> s.withColor(0xFF888888))
                ),
                mouseX, mouseY
            );
        }
    }

    private void drawBorder(DrawContext ctx, int x, int y, int w, int h, int color) {
        ctx.fill(x,         y,         x + w,     y + 1,     color);
        ctx.fill(x,         y + h - 1, x + w,     y + h,     color);
        ctx.fill(x,         y,         x + 1,     y + h,     color);
        ctx.fill(x + w - 1, y,         x + w,     y + h,     color);
    }

    private void drawButton(DrawContext ctx, int x, int y, int w, int h, String label, int mouseX, int mouseY) {
        boolean hov = mouseX >= x && mouseX < x + w && mouseY >= y && mouseY < y + h;
        ctx.fill(x, y, x + w, y + h, hov ? 0xFF006644 : 0xFF003322);
        drawBorder(ctx, x, y, w, h, BORDER_COLOR);
        int tx = x + (w - textRenderer.getWidth(label)) / 2;
        int ty = y + (h - 8) / 2;
        ctx.drawText(textRenderer, Text.literal(label), tx, ty, 0xFF00FF88, false);
    }

    @Override
    public boolean mouseClicked(double mouseX, double mouseY, int button) {
        int panelX  = (this.width  - PANEL_W) / 2;
        int panelY  = (this.height - PANEL_H) / 2;
        int bottomY = panelY + PANEL_H - 20;

        int gridX = panelX + 5;
        int gridY = panelY + 36;
        int startIdx = scrollOffset * COLS;

        for (int i = startIdx; i < Math.min(startIdx + COLS * VISIBLE_ROWS, filteredItems.size()); i++) {
            int col = (i - startIdx) % COLS;
            int row = (i - startIdx) / COLS;
            int sx  = gridX + col * SLOT_SIZE;
            int sy  = gridY + row * SLOT_SIZE;

            if (mouseX >= sx && mouseX < sx + SLOT_SIZE
             && mouseY >= sy && mouseY < sy + SLOT_SIZE) {
                selectedItem = filteredItems.get(i);
                giveAmount   = 1;
                return true;
            }
        }

        if (selectedItem != null) {
            if (mouseX >= panelX + PANEL_W - 70 && mouseX < panelX + PANEL_W - 58
             && mouseY >= bottomY - 1 && mouseY < bottomY + 11) {
                if (giveAmount > 1) giveAmount--;
                return true;
            }
            if (mouseX >= panelX + PANEL_W - 42 && mouseX < panelX + PANEL_W - 30
             && mouseY >= bottomY - 1 && mouseY < bottomY + 11) {
                if (giveAmount < 64) giveAmount++;
                return true;
            }
            if (mouseX >= panelX + PANEL_W - 28 && mouseX < panelX + PANEL_W - 3
             && mouseY >= bottomY - 1 && mouseY < bottomY + 11) {
                giveItem();
                return true;
            }
        }

        return super.mouseClicked(mouseX, mouseY, button);
    }

    private void giveItem() {
        if (client == null || client.player == null || selectedItem == null) return;
        ItemStack stack = new ItemStack(selectedItem, giveAmount);
        boolean added = client.player.getInventory().insertStack(stack);
        if (!added) {
            client.player.dropItem(stack, false);
        }
    }

    // 1.21.x signature: (double mouseX, double mouseY, double horizontalAmount, double verticalAmount)
    @Override
    public boolean mouseScrolled(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int totalRows = (int) Math.ceil((double) filteredItems.size() / COLS);
        int maxScroll = Math.max(0, totalRows - VISIBLE_ROWS);

        if (verticalAmount < 0) {
            scrollOffset = Math.min(scrollOffset + 1, maxScroll);
        } else {
            scrollOffset = Math.max(scrollOffset - 1, 0);
        }
        return true;
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 256) {
            this.close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
