package com.example.drill;

import org.bukkit.*;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.command.*;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.*;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;

public class DrillPlugin extends JavaPlugin implements Listener, CommandExecutor {

    private NamespacedKey drillKey;
    private boolean breaking = false;

    @Override
    public void onEnable() {
        drillKey = new NamespacedKey(this, "drill");
        getServer().getPluginManager().registerEvents(this, this);
        getCommand("drill").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("الأمر ده للاعبين بس");
            return true;
        }
        player.getInventory().addItem(createDrill());
        player.sendMessage("§aاتاخدت الدريل!");
        return true;
    }

    private ItemStack createDrill() {
        ItemStack item = new ItemStack(Material.NETHERITE_PICKAXE);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName("§6§lدريل الماينر");
        meta.setUnbreakable(true);
        meta.addEnchant(Enchantment.DIG_SPEED, 5, true);
        meta.getPersistentDataContainer().set(drillKey, PersistentDataType.BYTE, (byte) 1);
        item.setItemMeta(meta);
        return item;
    }

    private boolean isDrill(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return false;
        return item.getItemMeta().getPersistentDataContainer()
                .has(drillKey, PersistentDataType.BYTE);
    }

    @EventHandler(ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        if (breaking) return;

        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        if (!isDrill(tool)) return;
        if (player.isSneaking()) return;

        BlockFace face = player.getTargetBlockFace(6);
        if (face == null) face = BlockFace.UP;

        Block center = event.getBlock();
        breaking = true;
        try {
            for (int a = -1; a <= 1; a++) {
                for (int b = -1; b <= 1; b++) {
                    if (a == 0 && b == 0) continue;

                    int dx, dy, dz;
                    switch (face) {
                        case NORTH, SOUTH -> { dx = a; dy = b; dz = 0; }
                        case EAST, WEST   -> { dx = 0; dy = b; dz = a; }
                        default           -> { dx = a; dy = 0; dz = b; }
                    }

                    Block target = center.getRelative(dx, dy, dz);
                    if (target.isEmpty() || target.isLiquid()
                            || target.getType() == Material.BEDROCK) continue;

                    BlockBreakEvent sub = new BlockBreakEvent(target, player);
                    Bukkit.getPluginManager().callEvent(sub);
                    if (sub.isCancelled()) continue;

                    target.breakNaturally(tool);
                }
            }
        } finally {
            breaking = false;
        }
    }

    @Override
    public boolean onTabComplete(CommandSender sender, Command cmd, String label, String[] args) {
        return java.util.Collections.emptyList();
    }
}
